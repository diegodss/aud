/var/www/html/auditoria/storage/logs: writing permissions
apt install composer
browser to new_software dir
composer update

- laravel/framework v5.2.9 requires ext-mbstring * -> the requested PHP extension mbstring is missing from your system.
