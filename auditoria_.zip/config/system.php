<?php

// config/constants.php

return [
    'system_name' => 'Sistema de Auditorias',
    'analytics_code' => 'uywmasdklj',
    'items_page' => '25',
    'items_page_range' => array("10" => "10", "25" => "25", "50" => "50")
];
